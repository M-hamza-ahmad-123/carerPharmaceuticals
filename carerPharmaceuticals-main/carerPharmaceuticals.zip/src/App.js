import "./App.css";
import Main from "./components/main";
import Routers from "./routes";

function App() {
  return <Routers></Routers>;
}

export default App;
