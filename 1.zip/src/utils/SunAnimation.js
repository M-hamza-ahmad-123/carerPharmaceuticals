import React from 'react';
import './SunAnimation.css'; // Ensure that you import the CSS file


  

function SunAnimation  () {
  return (
    <div className="container">
      <h1 className="home-title">
        <span>Carer Pharmaceuticals</span>
        <span>Just Die ! we dont care </span>
      </h1>
    </div>
  );
};

export default SunAnimation;
